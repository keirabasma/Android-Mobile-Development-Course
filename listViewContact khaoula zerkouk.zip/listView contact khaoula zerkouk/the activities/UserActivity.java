package com.example.listviewexemple;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.example.listviewexemple.databinding.ActivityUserBinding;

public class UserActivity extends AppCompatActivity {
ActivityUserBinding  binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityUserBinding.inflate(getLayoutInflater());
    setContentView(binding.getRoot());

    Intent intent = this.getIntent();
    if(intent!=null){
        String names = intent.getStringExtra("names");
        String phoneNumbers = intent.getStringExtra("phoneNumbers");
        String countries = intent.getStringExtra("countries");
        int imageId = intent.getIntExtra("imageId",R.drawable.i);
        binding.nameProfile.setText(names);
        binding.phoneProfile.setText(phoneNumbers);
        binding.countryuser.setText(countries);
        binding.ImageProfile.setImageResource(imageId);

    }
    }
}