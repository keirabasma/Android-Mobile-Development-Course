package com.example.listviewexemple;
public class user {
    String name, lastMessage, lastMessageTime, phoneNumber, country;
    int imgID;

    public user(String name, String lastMessage, String lastMessageTime, String phoneNumber, String country, int imgID) {
        this.name = name;
        this.lastMessage = lastMessage;
        this.lastMessageTime = lastMessageTime;
        this.phoneNumber = phoneNumber;
        this.country = country;
        this.imgID = imgID;
    }
}



