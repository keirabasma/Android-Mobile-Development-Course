package com.example.listviewexemple;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import com.example.listviewexemple.databinding.ActivityMainBinding;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ActivityMainBinding binding;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        int[] imageId= {R.drawable.a,
                        R.drawable.h,
                        R.drawable.c,
                        R.drawable.d,
                        R.drawable.e,
                        R.drawable.f,
                        R.drawable.g,
                        R.drawable.c,
                        R.drawable.d,
                        R.drawable.e,
                        R.drawable.f,
                        R.drawable.g,
        };
        String[] names = {"John", "Emily", "Michael", "Sophia", "Daniel", "Olivia", "William","Michael", "Sophia", "Daniel", "Olivia", "William"};
        String[] lastMessages = {"Hello", "How are you?", "I'll be there soon", "Can't wait to see you", "Remember to bring the documents", "Have a great day!", "See you tomorrow", "I'll be there soon", "Can't wait to see you", "Remember to bring the documents", "Have a great day!", "See you tomorrow"};
        String[] lastMessageTimes = {"10:30 AM", "3:45 PM", "9:15 AM", "6:20 PM", "1:55 PM", "11:10 AM", "8:05 PM", "9:15 AM", "6:20 PM", "1:55 PM", "11:10 AM", "8:05 PM"};
        String[] phoneNumbers = {"1234567890", "9876543210", "5551234567", "9998887777", "1112223333", "4445556666", "7778889999", "5551234567", "9998887777", "1112223333", "4445556666", "7778889999"};
        String[] countries = {"USA", "Canada", "France", "Australia", "Germany", "Brazil", "Japan" , "France", "Australia", "Germany", "Brazil", "Japan"};

        ArrayList<user> userArrayList= new ArrayList<>();
        for (int i = 0; i<imageId.length; i++){
           user u=new user(names[i],lastMessages[i],lastMessageTimes[i],phoneNumbers[i],countries[i],imageId[i]);
           userArrayList.add(u);
        }

        //create adapter
        ListAdapter listAdapter = new ListAdapter(MainActivity.this,userArrayList);
        binding.listview.setAdapter(listAdapter);
        binding.listview.setClickable(true);
        binding.listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent i =new Intent(MainActivity.this,UserActivity.class);
                i.putExtra("names",names[position]);
                i.putExtra("phoneNumbers",phoneNumbers[position]);
                i.putExtra("countries",countries[position]);
                i.putExtra("imageId",imageId[position]);
                startActivity(i);



            }
        });
    }
}