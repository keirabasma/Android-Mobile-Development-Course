package com.example.interogation;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity {
   // Button length = findViewById(R.id.edt1);
  //  Button common = findViewById(R.id.edt2);
   // Button Clear = findViewById(R.id.edt3);
    private EditText ed1, ed2, ed3, ed4;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            // Initialisation des champs de texte
            ed1 = findViewById(R.id.ed1);
            ed2 = findViewById(R.id.ed2);
            ed3 = findViewById(R.id.ed3);
            ed4 = findViewById(R.id.ed4);


            // Initialisation des boutons
            Button buttonLength = findViewById(R.id.buttonLongueur);
            Button buttonCommon = findViewById(R.id.buttonCalculer);
            Button buttonClear = findViewById(R.id.buttonClear);



            // Ajouter un écouteur de clic pour le bouton de calcul de la longueur
            buttonLength.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    traiterLongueur();
                }
            });

            // Ajouter un écouteur de clic pour le bouton de recherche des caractères communs
            buttonCommon.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    traiterCaracteresCommuns();
                }
            });

            // Ajouter un écouteur de clic pour le bouton de suppression
            buttonClear.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    clearButtonOnClick();
                }
            });
        }


    public void traiterLongueur() {
        // Récupérer les valeurs des champs de texte
        String mot1 = ed1.getText().toString();
        String mot2 = ed2.getText().toString();

        // Calculer la longueur
        int longueur = mot1.length() + mot2.length();

        // Afficher la longueur dans le champ de texte approprié
        ed3.setText(String.valueOf(longueur));
    }

    public void traiterCaracteresCommuns() {
        // Récupérer les valeurs des champs de texte
        String mot1 = ed1.getText().toString();
        String mot2 = ed2.getText().toString();

        // Trouver les caractères communs
        StringBuilder communs = new StringBuilder();
        int res=0;
        for (int i = 0; i < mot1.length(); i++) {
            char c = mot1.charAt(i);
            if (mot2.contains(String.valueOf(c))) {
                communs.append(c);
                res ++;
            }
        }

        // Afficher les caractères communs dans le champ de texte approprié
        // Afficher les caractères communs dans le champ de texte approprié
        ed4.setText(String.valueOf(res));
    }





    public void clearButtonOnClick() {
        // Effacer le contenu de tous les champs de texte
        ed1.setText("");
        ed2.setText("");
        ed3.setText("");
        ed4.setText("");
    }
}

