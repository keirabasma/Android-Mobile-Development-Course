package com.example.calculatordoublenombre;

import static com.example.calculatordoublenombre.R.id.lell;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class dexiemActiviy extends AppCompatActivity {
    private TextView text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dexiem_activiy);

        Intent intent = getIntent();
        int result = intent.getIntExtra("mess", 0);
        text = findViewById(R.id.lell);

        if (result == 0) {
            text.setText("La valeur de 'mess' est nulle");
        } else {
            text.setText("activity mess"+result);
        }
    }
}
