package com.example.calculatordoublenombre;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    private EditText inputNumber ;
    private TextView resultTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //le recuperation des vue
        inputNumber = findViewById(R.id.input_number);
        resultTextView = findViewById(R.id.result_text_view);

        // définition du comportement du bouton
        Button calculateButton;
        calculateButton  = findViewById(R.id.calculate_button);
        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // récupération du nombre sasai par l'utilisateur
                int number = Integer.parseInt(inputNumber.getText().toString());
                // calcul du double
                int result = number * 2;

                // affichage du résultat
                resultTextView.setText("Le double de " + number + " est " + result);


                    // creation du object intent ala djal le passage
                    Intent intent = new Intent(MainActivity.this,dexiemActiviy.class);
                    // ajouter le var res en tnq msg nommé "mess" a l'object intent
                    intent.putExtra("mess", result);
                    //Donner la ligne de code nécessaire pour lancer la deuxième
                    //activité.
                    startActivity(intent);

            }
        });


    }
}