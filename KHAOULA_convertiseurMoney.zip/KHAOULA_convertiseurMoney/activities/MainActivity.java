package com.example.converteurmoney;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.Menu;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.view.MenuInflater;
import android.widget.ImageView;
import android.widget.EditText;
import android.widget.*;

public class MainActivity extends AppCompatActivity {
    private EditText zoneText;
    private RadioGroup radioGroup;
    private Menu context_menu;
    private RadioButton dinar_to_euro,euro_to_dinar;
    private Button convertButton ;
    private TextView resultat;

    private float euroToDinar(float valeurEuro) {
        return (float) (valeurEuro * 140.45);
    }
    private float dinarsToEuro(float valeurDinar) {
        return (float) (valeurDinar * 0.0071);
    }
    //méthode pour convertir la devise en fonction du bouton radio sélectionné
    private void convertire(){
        String edt = zoneText.getText().toString();
        //float ValourNumeric = Float.valueOf(zoneText.getText().toString());
        //vérification si le champ de texte est vide
        if(edt.isEmpty()){
            Toast.makeText(MainActivity.this,"veiller entrer une valeur a convertir ",Toast.LENGTH_SHORT).show();
            return;
        }
        //les cham
        float ValourNumeric = Float.parseFloat(edt);
        float result;
        if(euro_to_dinar.isChecked()){
            result=euroToDinar(ValourNumeric);
            resultat.setText(String.format("%.2f DA",result));
        } else if (dinar_to_euro.isChecked()) {
            result= dinarsToEuro(ValourNumeric);
            resultat.setText(String.format("%.2f £",result));
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // la liaison des éléments de l'interface
        zoneText = findViewById(R.id.zoneText);
        LinearLayout ll = findViewById(R.id.ll);
        radioGroup = findViewById(R.id.radioGroup);
        dinar_to_euro = findViewById(R.id.dinar_to_euro);
        euro_to_dinar = findViewById(R.id.euro_to_dinar);
        convertButton = findViewById(R.id.convertButton);
        resultat = findViewById(R.id.resultat);

        //exemple d'une image
        ImageView image =new ImageView(this);
        image.setImageResource(R.drawable.img);
        //ll.addView(image);

        // Register the context menu with the radio buttons
        //registerForContextMenu(euro_to_dinar);
        //registerForContextMenu(dinar_to_euro);

        //lier le menu avec ce button
        registerForContextMenu(convertButton);

        // Associer la méthode convertir au bouton convertir
        convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                convertire();

            }
        });
    }

    //création du menu contextuel pour afficher les taux de conversion
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
    }

    //méthode pour gérer le clic sur les éléments du menu d'options
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.dinar_to_euro_context:
                Toast.makeText(this, "Taux de conversion dinar -> euro : 0.0071", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.euro_to_dinar_context:
                Toast.makeText(this, "Taux de conversion euro -> dinar : 140.45", Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu:
                // Show alert if input field is empty
                if (zoneText.getText().toString().trim().isEmpty()) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setMessage("Le champ en entrée est vide.")
                            .setPositiveButton("OK", null);
                    AlertDialog alert = builder.create();
                    alert.show();
                }

                return true;
            case R.id.exit_menu:
                finish();

            default:
                return super.onOptionsItemSelected(item);
        }
    }



}
